public class Hovedprogram {
    public static void main(String[] args) {
        Legesystem ls = new Legesystem();

        ls.kommandoLokke();
    }
}
