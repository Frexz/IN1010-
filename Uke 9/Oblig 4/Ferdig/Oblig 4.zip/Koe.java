public class Koe<T> extends Lenkeliste<T> {
    // Beholderen Koe har akkurat lik funksjonalitet som Lenkeliste så ingen metoder
    // trengs redefineres.
}
