public class BilBruk1 {
    public static void main(String[] args) {
        
        // Lager et bilobjekt og kaller skrivUt-metoden
        Bil1 bil = new Bil1();
        bil.skrivUt();
    }
}