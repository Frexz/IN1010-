public class Bil1 {
    
    // Metode som skriver ut 'Jeg er en bil'
    public void skrivUt() {
        System.out.println("Jeg er en bil.");
    }
}