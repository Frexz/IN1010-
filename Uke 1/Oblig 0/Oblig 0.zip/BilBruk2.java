public class BilBruk2 {
    public static void main(String[] args) {
        
        // Oppretter et bilobjekt med registreringsnummer og kaller skrivUt-metode
        Bil2 bil = new Bil2("PI 31415");
        bil.skrivUt();
    }
}